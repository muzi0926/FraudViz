<template>
  <div id="app">
    <transition name="fade">
      <Loading v-if="isLoading" />
    </transition>
    <LineUp
      :data="data || [{a: 123, a: 234}]"
      default-ranking="false"
      style="height: 840px"
      :highlight="highlight"
      @highlightChanged="highlightChanged"
    >
      <LineUpNumberColumnDesc
        v-for="item in csvdata || [
          {column: 'a', label: 'Test', domain: [1, 10], color: '#123456'},
          {column: 'a', label: 'Test', domain: [1, 10], color: '#123456'}]"
        :key="item.id"
        :column="item.column"
        :label="item.label"
        :domain="item.domain"
        :color="item.color"
      />
    </LineUp>
  </div>
</template>
<script>
import * as VueLineup from 'vue-lineup'
const { LineUp, LineUpNumberColumnDesc } = VueLineup
import Loading from '@/components/Loading'
// import { mapGetters } from 'vuex'

const data = []
const csvdata = []
const highlight = -1

export default {
  components: {
    Loading, LineUp, LineUpNumberColumnDesc
  },
  data() {
    return {
      data,
      csvdata,
      highlight,
      isLoading: true
    }
  },
  watch: {
    csvdata: function() {
      this.loadingPage()
    }
  },
  mounted() {
    const that = this // this vs that since classes are just a intermediate proxy
    that.loadingCsvData()
    alert(JSON.stringify(this.data))
    alert(JSON.stringify(this.csvdata))
  },
  methods: {
    loadingCsvData() {
      const result = this.$store.getters.lineupdata
      this.csvdata = result.csvData
      this.data = result.data
      // this.isLoading = false
    },
    loadingPage() {
      this.isLoading = false
    },
    highlightChanged(highlight) {
      this.highlight = highlight
    }
  }
}

</script>

<style>
  .fade-enter,
  .fade-leave-active {
    opacity: 0;
  }

  .fade-enter-active,
  .fade-leave-active {
    transition: opacity 0.5s;
  }
</style>
