<template>
  <div class="app-container">
    <el-form ref="form" :model="form" label-width="120px">
      <el-form-item label="year-begin">
        <el-select v-model="form.yearbegin" placeholder="year-begin">
          <el-option label="1998" value="1998" />
          <el-option label="1999" value="1999" />
          <el-option label="2000" value="2000" />
          <el-option label="2001" value="2001" />
          <el-option label="2002" value="2002" />
          <el-option label="2003" value="2003" />
          <el-option label="2004" value="2004" />
          <el-option label="2005" value="2005" />
          <el-option label="2006" value="2006" />
          <el-option label="2007" value="2007" />
          <el-option label="2008" value="2008" />
          <el-option label="2009" value="2009" />
          <el-option label="2010" value="2010" />
          <el-option label="2011" value="2011" />
          <el-option label="2012" value="2012" />
          <el-option label="2013" value="2013" />
          <el-option label="2014" value="2014" />
        </el-select>
      </el-form-item>
      <el-form-item label="year-end">
        <el-select v-model="form.yearend" placeholder="year-end">
          <el-option label="1998" value="1998" />
          <el-option label="1999" value="1999" />
          <el-option label="2000" value="2000" />
          <el-option label="2001" value="2001" />
          <el-option label="2002" value="2002" />
          <el-option label="2003" value="2003" />
          <el-option label="2004" value="2004" />
          <el-option label="2005" value="2005" />
          <el-option label="2006" value="2006" />
          <el-option label="2007" value="2007" />
          <el-option label="2008" value="2008" />
          <el-option label="2009" value="2009" />
          <el-option label="2010" value="2010" />
          <el-option label="2011" value="2011" />
          <el-option label="2012" value="2012" />
          <el-option label="2013" value="2013" />
          <el-option label="2014" value="2014" />
        </el-select>
      </el-form-item>
      <el-form-item>
        <el-button type="primary" @click="onSubmit">Create</el-button>
      </el-form-item>
    </el-form>
  </div>
</template>

<script>

export default {
  data() {
    return {
      form: {
        yearbegin: '',
        yearend: ''
      }
    }
  },
  methods: {
    onSubmit() {
      this.$store.dispatch('lineup/getdata', this.form).then(() => {
        this.$message({
          message: 'request success!',
          type: 'success'
        })
        this.$router.push({ path: '/lineup/index' })
      }).catch(() => {
        this.$message({
          message: 'error request: year-begin could not later than year-end!',
          type: 'warning'
        })
      })
    }
  }
}
</script>

<style scoped>
.line{
  text-align: center;
}
</style>

