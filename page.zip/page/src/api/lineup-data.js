import request from '@/utils/request'

export function getData() {
  return request({
    url: '/virtual/getData',
    method: 'get'
  })
}

export function getDataWithParam(data) {
  return request({
    url: '/virtual/getDatas',
    method: 'get',
    params: { data }
  })
}
