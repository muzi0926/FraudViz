import { getDataWithParam } from '@/api/lineup-data'

const state = {
  lineupdata: []
}

const mutations = {
  SET_LINEUP: (state, lineupdata) => {
    state.lineupdata = lineupdata
  }
}

const actions = {
  // get lineup data
  getdata({ commit }, data) {
    return new Promise((resolve, reject) => {
      if (data.yearbegin > data.yearend) { reject() }
      getDataWithParam(data).then(response => {
        const { data } = response
        alert(JSON.stringify(data))
        commit('SET_LINEUP', data)
        resolve()
      }).catch(error => {
        reject(error)
      })
    })
  }

}

export default {
  namespaced: true,
  state,
  mutations,
  actions
}

