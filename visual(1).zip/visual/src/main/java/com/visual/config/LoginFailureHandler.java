package com.visual.config;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Enumeration;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.security.core.AuthenticationException;
import org.springframework.security.web.authentication.AuthenticationFailureHandler;
import org.springframework.stereotype.Component;

import com.alibaba.fastjson.JSON;
import com.visual.domain.VO.ResultVO;
import com.visual.enums.ResponseResultCodeEnum;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class LoginFailureHandler implements AuthenticationFailureHandler{

	@Override
	public void onAuthenticationFailure(HttpServletRequest request, HttpServletResponse response,
			AuthenticationException exception) throws IOException, ServletException {
		StringBuilder sb = new StringBuilder();
        boolean isFirst = true;
        Enumeration<String> er = request.getParameterNames();
        while (er.hasMoreElements()) {
            String name = (String) er.nextElement();
            String value = request.getParameter(name);
            if (isFirst) {
                sb.append(name + "=" + value);
                isFirst = false;
            }
            else {
                if (value != null) {
                    sb.append("&" + name + "=" + value);
                }
                else {
                    sb.append("&" + name + "=");
                }
            }
        }
		log.error("form {}", sb.toString());
		log.error("request url {}", request.getRequestURI());
		String username = request.getParameter("username");
		log.error("get login username {}", username);
		String password = request.getParameter("password");
		log.error("get login password {}", password);
		response.setCharacterEncoding("UTF-8");
		ResultVO<Integer> resultVO = new ResultVO<>(ResponseResultCodeEnum.ERROR.getCode(),
				ResponseResultCodeEnum.ERROR.getMsg());
		PrintWriter printWriter = response.getWriter();
		printWriter.write(JSON.toJSONString(resultVO));
	}

}
