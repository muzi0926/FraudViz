package com.visual.config;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Component;

import com.alibaba.fastjson.JSON;
import com.visual.domain.VO.ResultVO;
import com.visual.enums.ResponseResultCodeEnum;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class LogoutSuccessHandler
		implements org.springframework.security.web.authentication.logout.LogoutSuccessHandler {

	@Override
	public void onLogoutSuccess(HttpServletRequest request, HttpServletResponse response, Authentication authentication)
			throws IOException, ServletException {
		String token = request.getHeader("Token");
		if (token.equals("") || token == null) {
			throw new ServletException();
		}
		ResultVO<Integer> json = new ResultVO<>(ResponseResultCodeEnum.SUCCESS.getCode(), ResponseResultCodeEnum.SUCCESS.getMsg());
		PrintWriter printWriter = response.getWriter();
		printWriter.write(JSON.toJSONString(json));
		log.info("logout success");
	}

}
