package com.visual.config;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.security.core.Authentication;
import org.springframework.security.web.authentication.AuthenticationSuccessHandler;
import org.springframework.stereotype.Component;

import com.alibaba.fastjson.JSON;
import com.visual.domain.VO.ResultVO;
import com.visual.enums.ResponseResultCodeEnum;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class LoginSuccessHandler implements AuthenticationSuccessHandler{

	
	@Override
	public void onAuthenticationSuccess(HttpServletRequest request, HttpServletResponse response,
			Authentication authentication) throws IOException, ServletException {
		log.info("login success");
		response.setCharacterEncoding("UTF-8");
		log.info(request.getRemoteAddr());
		log.info(request.getLocalAddr());
		ResultVO<String> resultVO = new ResultVO<>(ResponseResultCodeEnum.SUCCESS.getCode(),
				ResponseResultCodeEnum.SUCCESS.getMsg(), "123");
		PrintWriter printWriter = response.getWriter();
		printWriter.write(JSON.toJSONString(resultVO));
	}

}
