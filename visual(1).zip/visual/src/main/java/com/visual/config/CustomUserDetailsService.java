package com.visual.config;

import java.util.ArrayList;
import java.util.List;

import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

@Service
public class CustomUserDetailsService implements UserDetailsService {
//	
//	@Autowired
//	private UserService userService;
//	
	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
//		User user = userService.selectByUsername(username);
//        if (user == null || user.getState() != 1) {
//            throw new UsernameNotFoundException("用户不存在！");
//        }
        List<SimpleGrantedAuthority> simpleGrantedAuthorities = new ArrayList<>();
//        if (user.getRole() > 0) {
        	simpleGrantedAuthorities.add(new SimpleGrantedAuthority("USER"));
//        }
        return new org.springframework.security.core.userdetails.User("admin", new BCryptPasswordEncoder().encode("123456"), simpleGrantedAuthorities);
	}

}
