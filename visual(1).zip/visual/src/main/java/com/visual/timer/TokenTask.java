package com.visual.timer;

import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.visual.util.TokenUtil;

@Component
public class TokenTask {

	@Scheduled(cron = "0 0 0 * * ?") // 每天凌晨
	private void initToken() {
		TokenUtil.init();
	}
	
}
