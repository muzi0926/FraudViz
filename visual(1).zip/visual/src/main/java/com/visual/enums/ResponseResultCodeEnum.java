package com.visual.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
@Getter
public enum ResponseResultCodeEnum {

    /*通用成功*/
    SUCCESS(200, "成功"),

    /*通用系统异常*/
    ERROR(400, "系统出现异常"),
    
    /*非法Token*/
    INVALID_TOKEN(50008, "非法token"),
    
    /*Token超时*/
    TOKEN_OVERTIME(50014, "token超时"),
    
    /*非法访问*/
    INVALID_ACCESS(50004, "非法访问"),
    
    /*登录失败*/
    LOGIN_ERROR(54004, "登录失败"),
    
    /*验证码错误*/
    VERIFY_CODE_ERROR(51001, "验证码错误"),
    
    /*excel格式错误*/
    EXCEL_FORMAT_ERROR(53000, "excel格式错误"),
    
    /*类型类别不存在*/
    EXCEL_FORMAT_INVALID_TYPE(53001, "类型类别不存在"),
    
    /*类别不存在*/
    EXCEL_FORMAT_INVALID_CATEGORY(53002, "类别不存在"),
    
    /*责任人不存在*/
    EXCEL_FORMAT_INVALID_PERSON(53003, "责任人不存在"),
    
    /*请求参数异常*/
    REQUEST_PARAMS_ERROR(1001, "参数异常"),
    
    /*添加应用系统异常*/
    ADD_TENANT_ERROR(5001, "添加应用系统出现异常"),
    
    /*更新数据异常*/
    UPDATE_DATA_ERROR(50002, "更新数据出现异常"),
	
	/*不允许删除分类下面的子分类*/
    DELETE_CATEGORY_HASSUB_ERROR(5201, "分类下面存在子分类"),
    /*分类不存在*/
    CATEGORY_NOT_FIND_ERROR(5202, "不存在该分类"),
	
	
    /*密码错误*/
    PASSWORD_VALIDATE_ERROR(5404, "密码错误"),
	/*用户不存在*/
    PERSON_NOT_FIND_ERROR(5404, "用户不存在");
	
    /**
     * 结果编码
     */
    private int code;
    /**
     * 结果消息
     */
    private String msg;

}
