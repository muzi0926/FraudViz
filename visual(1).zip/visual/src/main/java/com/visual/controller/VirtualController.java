package com.visual.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.alibaba.fastjson.JSON;
import com.visual.domain.CsvLineupDataFormat;
import com.visual.domain.VO.ResultVO;
import com.visual.enums.ResponseResultCodeEnum;
import com.visual.util.HttpUtil;
import com.visual.util.TransformDataUtil;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@RequestMapping("/virtual")
public class VirtualController {

	@PostMapping("/restful")
	public String restful(@RequestParam String data) throws Exception {
		String yearBegin = JSON.parseObject(data).getString("yearBegin");
		String yearEnd = JSON.parseObject(data).getString("yearEnd");
		String resultString = HttpUtil.httpGet("/getData", yearBegin, yearEnd);
		System.out.println(resultString);
		return "hello";
	}

	@GetMapping("/getData")
	public CsvLineupDataFormat csvDatas() throws Exception {
		log.info("required for data");
		List<String> skipList = getSkipList(2001, 2008);
		return TransformDataUtil.dataTranslate("Final_20200117.csv", skipList);
	}

	@GetMapping("/getDatas")
	public ResultVO<CsvLineupDataFormat> csvDatas(@RequestParam String data) throws Exception {
		log.info("required for data");
		int yearBegin = JSON.parseObject(data).getInteger("yearbegin");
		int yearEnd = JSON.parseObject(data).getInteger("yearend");
		List<String> skipList = getSkipList(yearBegin, yearEnd);
		ResultVO<CsvLineupDataFormat> resultVO = new ResultVO<CsvLineupDataFormat>(
				ResponseResultCodeEnum.SUCCESS.getCode(), ResponseResultCodeEnum.SUCCESS.getMsg(),
				TransformDataUtil.dataTranslate("Final_20200117.csv", skipList));
		return resultVO;
	}

	@GetMapping("/hello")
	public CsvLineupDataFormat hello() throws Exception {
		String result = HttpUtil.hpptGetNOArgs("/getFinal");
		String fileName = JSON.parseObject(result).getString("data");
		List<String> skipList = new ArrayList<>();
		CsvLineupDataFormat csvLineupDataFormat = TransformDataUtil.dataTranslate(fileName, skipList);
		return csvLineupDataFormat;
	}

	private List<String> getSkipList(int yearBegin, int yearEnd) {
		List<String> skipList = new ArrayList<>();
		for (Integer i = 1998; i <= 2014; i++) {
			if (i < yearBegin || i > yearEnd) {
				skipList.add(i.toString());
			}
		}
		return skipList;
	}

}
