package com.visual.aspect;

import javax.servlet.http.HttpServletRequest;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import com.visual.domain.VO.ResultVO;
import com.visual.enums.ResponseResultCodeEnum;
import com.visual.util.TokenUtil;

@Aspect
@Component
public class RoleCheckAspect{

	@Pointcut("@annotation(com.visual.annotation.Role)")
	public void RolePointCut() {};
	
	@Around("RolePointCut()")
	public Object doMethodCheckIdentity(ProceedingJoinPoint joinPoint) throws Throwable {
		ServletRequestAttributes attributes = (ServletRequestAttributes)RequestContextHolder.getRequestAttributes();
		HttpServletRequest request = attributes.getRequest();
		String token = request.getHeader("Token");
		int code = TokenUtil.verifyToken(token);
		if (code != 200) {
			return new ResultVO<Integer>(ResponseResultCodeEnum.INVALID_TOKEN.getCode(), ResponseResultCodeEnum.INVALID_TOKEN.getMsg());
		}
		return joinPoint.proceed();
	}
	
}
