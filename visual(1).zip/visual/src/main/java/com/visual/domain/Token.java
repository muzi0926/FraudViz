package com.visual.domain;

import java.util.Date;

import lombok.Data;

@Data
public class Token {

	private Date time;
	
	private String userId;
	
	private String user;
		
	private String uuid;
	
	private String ip;
	
	private Integer role;
	
	private String token;
	
}
