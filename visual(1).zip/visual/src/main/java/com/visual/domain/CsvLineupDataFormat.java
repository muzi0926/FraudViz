package com.visual.domain;

import java.util.List;

import com.alibaba.fastjson.JSONArray;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class CsvLineupDataFormat {

	private List<CsvData> csvData;
	
	private JSONArray data;	
}
