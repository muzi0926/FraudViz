package com.visual.domain;

import lombok.Data;

@Data
public class CsvData {
	
	private Integer id;

	private String column;
	
	private String title;
	
	private Double[] domain;
		
	private String color;
	
}
