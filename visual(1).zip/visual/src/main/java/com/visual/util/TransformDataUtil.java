package com.visual.util;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.google.common.collect.ImmutableList;
import com.visual.domain.Csv;
import com.visual.domain.CsvData;
import com.visual.domain.CsvLineupDataFormat;

public class TransformDataUtil {

//	private static final String PATH = "C:/Users/10929/Desktop/";
	
//	private static final String PATH = "/usr/local/visual/";
	
	private static final String PATH = "D:/";
	
	private static final List<String> COLOR_LIST = ImmutableList.<String>builder()
			.add("#f6e58d").add("#ffbe76").add("#ff7979").add("#badc58")
			.add("#dff9fb").add("#f9ca24").add("#f0932b").add("#eb4d4b")
			.add("#6ab04c").add("#c7ecee").add("#7ed6df").add("#e056fd")
			.add("#686de0").add("#30336b").add("#95afc0").add("#22a6b3")
			.add("#be2edd").add("#4834d4").add("#ffa299").add("#535c68").build();
		
	public static CsvLineupDataFormat dataTranslate(String fileName, List<String> skipList) throws Exception {
		if (!fileName.split("\\.")[1].equals("csv")) {
			throw new RuntimeException("illegal filename");
		}
		Csv csv = readCsv(PATH, fileName);
		String[] title = csv.getTitle();
		List<String[]> content = csv.getContent();
		List<CsvData> list = new ArrayList<>(title.length);
		
		JSONArray data = new JSONArray();

		for (String[] d : content) {
			JSONObject jsonObject = new JSONObject(new LinkedHashMap<>());
			for (int i = 0; i < title.length; i++) {
				if (skipList.size() > 0) {
					if (skipList.contains(title[i])) {
						continue;
					}
				}
				double value = 0;
				if (!d[i].trim().equals("")) {
					value = Double.parseDouble(d[i]);
				}
				jsonObject.put(title[i], value);
			}
			data.add(jsonObject);
		}
		
		for (int i = 0, color = 0, id = 1; i < title.length; i++, color++, id++) {
			if (skipList.size() > 0) {
				if (skipList.contains(title[i])) {
					color--;
					id--;
					continue;
				}
			}
			CsvData csvData = new CsvData();
			csvData.setId(id);
			csvData.setTitle(title[i]);
			csvData.setColumn(title[i]);
			double max = 0;
			double min = 0;
			
			for (String[] d : content) {
				double value = 0;
				if (!d[i].trim().equals("")) {
					value = Double.parseDouble(d[i]);
				}
				if (value > max) {
					max = value;
				}
				if (value < min) {
					min = value;
				}
			}
			Double[] domain = {min, max};
			csvData.setDomain(domain);
			if (color > 19) {
				color = 0;
			}
			csvData.setColor(COLOR_LIST.get(color));
			list.add(csvData);
		}
		return new CsvLineupDataFormat(list, data);
	}
	
	public static Csv readCsv(String path, String fileName) throws Exception {
		List<String[]> content = new ArrayList<>();
		BufferedReader reader = new BufferedReader(new FileReader(path + fileName));
		String [] title = reader.readLine().split(",");
        String line = null;    
        while((line=reader.readLine())!=null){    
            String item[] = line.split(",");
            content.add(item);
        }
        reader.close();
        Csv csv = new Csv();
        csv.setTitle(title);
        csv.setContent(content);
        return csv;
	}
	
//	public static void main(String[] args) throws Exception {
//		dataTranslate("Final_20200117.csv");
//	}
	
}
