package com.visual.util;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.TimeZone;

import org.apache.commons.lang3.StringUtils;


/**
 * 一些日期处理的辅助类
 * <p>
 * 
 * </p>
 * 
 * @author Administrator
 * @version 1.0
 */
public class DateTimeUtil {
	
	private DateTimeUtil() {
		
	}

	/**
	 * 从字符串中取得日期，比如字符串2004-9-9转化成日期型
	 * 
	 * @param sDate
	 * @return
	 * @throws ParseException
	 */
	

	public static Date getDateByFormat(String sDate) throws ParseException {
		if (StringUtils.isBlank(sDate)) {
			return null;
		}
		SimpleDateFormat simformat = new SimpleDateFormat("yyyy-MM-dd");
		Date date = simformat.parse(sDate);

		return date;
	}

	public static long getFormatDate(String sDate) {
		Date date = null;
		try {
			date = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse(sDate);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return date.getTime() / 1000;
	}

	/**
	 * 将日期转换成字符串表示，如2004-09-09 17:09:09
	 * 
	 * @param d
	 * @return
	 */
	public static String getFormatDate(Date d) {
		return new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(d);
	}

	/**
	 * 将日期转换成字符串
	 * 
	 * @param d
	 * @return
	 */
	public static String getFormatDateString(Date d) {
		return new SimpleDateFormat("yyyy-MM-dd").format(d);
	}

	/**
	 * 将日期转换成字符串表示，如2004-09-09 17:09:09
	 * 
	 * @param d
	 * @return
	 */
	public static String getFormatDay(Date d) {
		return new SimpleDateFormat("yyyy/MM/dd").format(d);
	}

	/**
	 * @return 返回字符串型式表示的当前时间如: 2002-12-10 12:10:18
	 */
	public static String now() {
		GregorianCalendar calenda = new GregorianCalendar(TimeZone.getTimeZone("GMT+08:00"));
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		return sdf.format(calenda.getTime());
	}

	/**
	 * @return 带上时分秒的当前时间
	 */
	public static Date currentTime() {
		GregorianCalendar calenda = new GregorianCalendar(TimeZone.getTimeZone("GMT+08:00"));
		return calenda.getTime();
	}
	
	public static String currentYear() {
		GregorianCalendar calenda = new GregorianCalendar(TimeZone.getTimeZone("GMT+08:00"));
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy");
		return sdf.format(calenda.getTime());
	}
	
	public static String currentMonth() {
		GregorianCalendar calenda = new GregorianCalendar(TimeZone.getTimeZone("GMT+08:00"));
		SimpleDateFormat sdf = new SimpleDateFormat("MM");
		return sdf.format(calenda.getTime());
	}
	
	public static String currentDay() {
		GregorianCalendar calenda = new GregorianCalendar(TimeZone.getTimeZone("GMT+08:00"));
		SimpleDateFormat sdf = new SimpleDateFormat("dd");
		return sdf.format(calenda.getTime());
	}

	/**
	 * 获得当前日期的时间格式
	 * 
	 * @return
	 */
	public static String currentDate() {
		GregorianCalendar calenda = new GregorianCalendar(TimeZone.getTimeZone("GMT+08:00"));
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		return sdf.format(calenda.getTime());
	}

	public static Date toDate() throws ParseException {
		GregorianCalendar calenda = new GregorianCalendar(TimeZone.getTimeZone("GMT+08:00"));
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		return sdf.parse(sdf.format(calenda.getTime()));
	}

	
	/**
	 * 获取昨天的日期
	 * 
	 * @return
	 */
	public static String yesterDate() {
		Calendar.getInstance(TimeZone.getTimeZone("GMT+08:00"));
		DateFormat dformat = new SimpleDateFormat("yyyy-MM-dd");
		Calendar c = Calendar.getInstance(TimeZone.getTimeZone("GMT+08:00"));
		c.add(Calendar.DAY_OF_YEAR, -1);
		String etime = dformat.format(c.getTime());
		return etime;
	}

	public static String getDateByLong(long time) {

		Date date = new Date(time);

		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

		return sdf.format(date);
	}

	public static Long getDistanceDays(Date one, Date two) throws Exception {
		Long days = 0L;
		try {
			long time1 = one.getTime();
			long time2 = two.getTime();
			long diff;
			if (time1 <= time2) {
				diff = time2 - time1;
			} else {
				diff = time1 - time2;
			}
			days = diff / (1000 * 60 * 60 * 24);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return days;
	}

	public static String compareDays(Date one, Date two) throws Exception {
		if (one == null || two == null) {
			return "";
		}
		try {
			long time1 = one.getTime();
			long time2 = two.getTime();
			if (time1 <= time2) {
				return "2";
			} else {
				return "1";
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		return "";
	}

	public static Date long2date(String l) throws Exception {
		if (StringUtils.isBlank(l)) {
			return null;
		}
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		String d = format.format(Long.valueOf(l));
		Date date = format.parse(d);

		return date;
	}

	/**
	 * 获取day天前后的日期时间
	 * 
	 * @return
	 */
	public static Date plusDate(Date date, String day) throws Exception {
		if (date == null) {
			return null;
		}
		if (day == null) {
			return null;
		}
		Calendar c = Calendar.getInstance(TimeZone.getTimeZone("GMT+08:00"));
		c.setTime(date);
		c.add(Calendar.DAY_OF_YEAR, Integer.valueOf(day));
		return c.getTime();
	}
	
	public static Date plusDate(Date date, int day) throws Exception {
		if (date == null) {
			return null;
		}
		Calendar c = Calendar.getInstance(TimeZone.getTimeZone("GMT+08:00"));
		c.setTime(date);
		c.add(Calendar.DAY_OF_YEAR, Integer.valueOf(day));
		return c.getTime();
	}
	
	/**
	 * 获取hour小时前后的日期时间
	 * 
	 * @return
	 */
	public static Date plusHour(Date date, String hour) {
		if (date == null) {
			return null;
		}
		if (hour == null) {
			return null;
		}
		Calendar c = Calendar.getInstance(TimeZone.getTimeZone("GMT+08:00"));
		c.setTime(date);
		c.add(Calendar.HOUR_OF_DAY, Integer.valueOf(hour));
		return c.getTime();
	}
	
	/**
     * 用于计算两个日期之间的间隔 （原时间差工具类跨年计算错误）
     * @param first 第一个日期(取最近的时间)
     * @param second 第二个日期（较远的时间）
     * @return 返回天数差
     *
     */
    public static int longOfTwoDate(Date first, Date second) throws ParseException {
        //格式化时间
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
        //将时间转化成String类型
        String fDate = format.format(first);
        String sDate = format.format(second);
        //解析String为Date
        Date date1 = format.parse(fDate);
        Date date2 = format.parse(sDate);
        //两日期相减，所得毫秒数 除以1000得秒 除以3600得小时 除24得天数得到两个日期的间隔
        int day = (int) ((date1.getTime() - date2.getTime()) / (1000*3600*24));
        //返回天数
        return day;
    }
	
    public static String getFirstDayOfMonth(Integer year, Integer month) {
        if (month < 10)
        	return year + "-0" + month + "-01";
        return year + "-" + month + "-01";
    }
    
    public static String getLastDayOfMonth(Integer year, Integer month) {
    	Calendar calendar = Calendar.getInstance();
        //设置年份
    	calendar.set(Calendar.YEAR,year);
        //设置月份
    	calendar.set(Calendar.MONTH, month-1);
        //获取某月最大天数
        int lastDay = calendar.getActualMaximum(Calendar.DAY_OF_MONTH);
        //设置日历中月份的最大天数
        calendar.set(Calendar.DAY_OF_MONTH, lastDay);
        //格式化日期
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        String lastDayOfMonth = sdf.format(calendar.getTime());
        return lastDayOfMonth;
    }

	public static Date plusMonth(Date date, int month) {
		if (date == null) {
			return null;
		}
		Calendar c = Calendar.getInstance(TimeZone.getTimeZone("GMT+08:00"));
		c.setTime(date);
		c.add(Calendar.MONTH, month);
		return c.getTime();
	}

	public static int getWeek(Date updateDate) {
		Calendar calendar = Calendar.getInstance(TimeZone.getTimeZone("GMT+08:00"));
		calendar.setTime(updateDate);
		int week = calendar.get(Calendar.DAY_OF_WEEK);
		return week;
	}

	public static Date getDateOfWeek(int week) throws Exception {
		Calendar calendar = Calendar.getInstance(TimeZone.getTimeZone("GMT+08:00"));
		calendar.setTime(toDate());
		calendar.set(Calendar.DAY_OF_WEEK, week);
		return calendar.getTime();
	}
	
	public static Date getDate(String day) throws Exception {
		Calendar calendar = Calendar.getInstance(TimeZone.getTimeZone("GMT+08:00"));
		calendar.setTime(toDate());
		int year = calendar.get(Calendar.YEAR);
		String date = year + "-" + day;
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		return sdf.parse(date);
	}

	public static Date nextDay(int day) throws Exception {
		Calendar calendar = Calendar.getInstance(TimeZone.getTimeZone("GMT+08:00"));
		calendar.setTime(toDate());
		int currentDay = calendar.get(Calendar.DAY_OF_MONTH);
		if (currentDay > day) {
			calendar.set(Calendar.MONTH, calendar.get(Calendar.MONTH) + 1);
		} 
		calendar.set(Calendar.DAY_OF_MONTH, day);
		return calendar.getTime();
	}

	public static String format(Date date) {
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
		return format.format(date);
	}

}