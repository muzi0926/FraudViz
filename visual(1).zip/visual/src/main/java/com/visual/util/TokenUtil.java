package com.visual.util;

import java.util.Map;

import com.auth0.jwt.JWT;
import com.auth0.jwt.JWTVerifier;
import com.auth0.jwt.algorithms.Algorithm;
import com.auth0.jwt.interfaces.Claim;
import com.auth0.jwt.interfaces.DecodedJWT;
import com.google.common.collect.ImmutableMap;
import com.visual.enums.ResponseResultCodeEnum;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class TokenUtil {
		
	private static final ImmutableMap<String, Object> MAP = ImmutableMap.<String, Object>builder().put("alg", "HS256").put("typ", "JWT").build();
	
	private static String KEY = IdUtil.generateShortUuid();
			
	public static int verifyToken(String token) {
		try {
			JWTVerifier verifier = JWT.require(Algorithm.HMAC256(KEY)).build();
			DecodedJWT jwt = verifier.verify(token);
			Map<String, Claim> content = jwt.getClaims();
			return ResponseResultCodeEnum.SUCCESS.getCode();
		} catch (Exception e) {
			return ResponseResultCodeEnum.INVALID_TOKEN.getCode();
		}
		
	}
	
	public static String generateToken(String ip) {
		String jwt = JWT.create().withHeader(MAP)
				.withClaim("uuid", IdUtil.get32UUID())
				.withClaim("ip", ip)
				.sign(Algorithm.HMAC256(KEY));
		return jwt;
	}
	
	public static void init() {
		KEY = IdUtil.generateShortUuid();
		log.info("Token init success");
	}
	
}
