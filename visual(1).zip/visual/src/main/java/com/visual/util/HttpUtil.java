package com.visual.util;

import java.net.URI;
import java.util.ArrayList;
import java.util.List;

import org.apache.http.HttpEntity;
import org.apache.http.NameValuePair;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.utils.URIBuilder;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;

public class HttpUtil {
	
	private static final String HOST = "127.0.0.1";
	
	private static final Integer PORT = 5000;
	
	public static String httpGet(String route, String yearBegin, String yearEnd) throws Exception {
		CloseableHttpClient httpClient = HttpClientBuilder.create().build();
		 
		// 参数
		URI uri = null;
		// 将参数放入键值对类NameValuePair中,再放入集合中
		List<NameValuePair> params = new ArrayList<>();
		params.add(new BasicNameValuePair("yearBegin", yearBegin));
		params.add(new BasicNameValuePair("yearEnd", yearEnd));
		// 设置uri信息,并将参数集合放入uri;
		// 注:这里也支持一个键值对一个键值对地往里面放setParameter(String key, String value)
		uri = new URIBuilder().setScheme("http").setHost(HOST)
				              .setPort(PORT).setPath(route)
				              .setParameters(params).build();

		// 创建Get请求
		HttpGet httpGet = new HttpGet(uri);
 
		// 响应模型
		CloseableHttpResponse response = null;
		// 配置信息
		RequestConfig requestConfig = RequestConfig.custom()
				// 设置是否允许重定向(默认为true)
				.setRedirectsEnabled(true).build();
 
		// 将上面的配置信息 运用到这个Get请求里
		httpGet.setConfig(requestConfig);
 
		// 由客户端执行(发送)Get请求
		response = httpClient.execute(httpGet);
 
		// 从响应模型中获取响应实体
		HttpEntity responseEntity = response.getEntity();
		String result = EntityUtils.toString(responseEntity);
		
		if (httpClient != null) {
			httpClient.close();
		}
		if (response != null) {
			response.close();
		}
		return result;
	}
	
	public static String hpptGetNOArgs(String route) throws Exception {
		CloseableHttpClient client = null;
        CloseableHttpResponse response = null;
        URI uri = new URIBuilder().setScheme("http").setHost(HOST)
	              .setPort(PORT).setPath(route).build();
        HttpGet httpGet = new HttpGet(uri);
        client = HttpClients.createDefault();
        response = client.execute(httpGet);
        HttpEntity entity = response.getEntity();
        String result = EntityUtils.toString(entity);
        if (response != null) {
            response.close();
        }
        if (client != null) {
            client.close();
        }
        return result;
	}

}
